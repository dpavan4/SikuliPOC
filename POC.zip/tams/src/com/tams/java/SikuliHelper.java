package com.tams.java;

import java.util.Iterator;

import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class SikuliHelper {
	
	private static Screen screen = new Screen();
    private static Pattern pattern;
    private static Match match;

    public final void click(String imageName) throws Exception {
    String imgPath =System.getProperty("user.dir")+"\\src\\com\\tams\\resources\\"+ imageName + ".png";
    pattern = new Pattern(imgPath);
    if (screen.exists(pattern) != null){
             match = screen.find(pattern);
             screen.click(match);
             Thread.sleep(1000);

    }
    else
            System.out.println("Object: " + imageName + " Not available in screen");
  Thread.sleep(1000);
}
    
    public final void doubleClick(String imageName) throws Exception {
        String imgPath =System.getProperty("user.dir")+"\\src\\com\\tams\\resources\\"+ imageName + ".png";
        pattern = new Pattern(imgPath);
        if (screen.exists(pattern) != null){
                 match = screen.find(pattern);
                 screen.click(match);

        }
        else
                System.out.println("Object: " + imageName + " Not available in screen");
      Thread.sleep(1000);
    }

 public void waitTypeValEnter(String imageName,String value) throws FindFailed, InterruptedException
    {
            String imgPath =System.getProperty("user.dir")+"\\src\\com\\tams\\resources\\"+ imageName + ".png";
    pattern = new Pattern(imgPath);
    screen.wait(pattern,5);
    Thread.sleep(1000);
            screen.type(value);
            Thread.sleep(1000);
            screen.type(Key.ENTER);
    }

public void waitTypeValTab(String imageName,String value) throws Exception {
    String imgPath =System.getProperty("user.dir")+"\\src\\com\\tams\\resources\\"+ imageName + ".png";
    pattern = new Pattern(imgPath);
    if (screen.exists(pattern) != null){
             match = screen.find(pattern);
             screen.type(match,value);
             Thread.sleep(1000);
             screen.type(Key.TAB);
    }
    else
            System.out.println("Object: " + imageName + " Not available in screen");
    Thread.sleep(1000);
}

public void waitTypeValdoubleTab(String imageName,String value) throws Exception {
    String imgPath =System.getProperty("user.dir")+"\\src\\com\\tams\\resources\\"+ imageName + ".png";
    pattern = new Pattern(imgPath);
    if (screen.exists(pattern) != null){
             match = screen.find(pattern);
             screen.type(match,value);
             Thread.sleep(1000);
             screen.type(Key.TAB);
             Thread.sleep(1000);
             screen.type(Key.TAB);
    }
    else
            System.out.println("Object: " + imageName + " Not available in screen");
    Thread.sleep(1000);
}

public void pressKey(String key) throws FindFailed, InterruptedException
{
       if(key == "Enter")
        screen.type(Key.ENTER);
       if(key == "Tab")
    	screen.type(Key.TAB);
}

public static void findTextAndType(String pageHeaderName, String fieldname, String value) throws FindFailed

{
		Region Reg = App.focus(pageHeaderName).window();
		for (Iterator<Match> M = Reg.findAllText(fieldname); M.hasNext();)
		{
			Match M1 = M.next();
			M1.setH(M1.getH() + 20);
			M1.setY(M1.getY() - 3);
			Region R1 = M1.right(M1.getW() + 15);
			R1.highlight();
			Pattern pattern = new Pattern("resources/image/Yellow.PNG");
			if (R1.exists(pattern) != null)
			{
				Match M2 = screen.find(pattern);
				M2.type(value + Key.TAB);
			}
		}
	}
}
