package com.tams.java;

import java.io.IOException;

import org.sikuli.script.App;
import org.sikuli.script.Key;
import org.sikuli.script.Region;

public class LaunchTAMS {

	public static void launchTAMS(String TAMSIP) throws IOException, InterruptedException{
		System.out.println("In method");
		Thread.sleep(5000);
		String command1= "c:\\windows\\system32\\net.exe use Q: \\\\172.30.19.73\\Client /User:genpt\\skinnynt password /P:yes";        
		String[] command = {"cmd.exe", "/C", "Start", ""};   
		Runtime.getRuntime().exec(command1);
		Thread.sleep(5000);
		Runtime.getRuntime().exec(command);
		App.focus("cmd.exe");
		Thread.sleep(5000);
		Region R = App.focusedWindow();
		R.type("Q:"+Key.ENTER);
		R.type("start.bat"+Key.ENTER);
		App TAMS;
		int waitInc = 0;
		do {
		     TAMS = App.focus("TAMS - Login");
		     if (TAMS!=null)
		     break;
		     System.out.println(TAMS);
		     Thread.sleep(7000);
		      waitInc++;
		     System.out.println("Loop..");           
		   }while(waitInc < 30);
		 Thread.sleep(50000);
	}
	
}
