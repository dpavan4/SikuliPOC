package com.tams.java;


public class Invoicing extends SikuliHelper {

	@org.testng.annotations.Test
	public void testTAMS() throws Exception {
		// TODO Auto-generated method stub
		SikuliHelper sikuliHelper = new SikuliHelper();
		LaunchTAMS.launchTAMS("172.30.19.73");
		sikuliHelper.waitTypeValTab("Emp_name", "5");
		sikuliHelper.waitTypeValEnter("Emp_pwd", "tams123");
		sikuliHelper.click("Ok");
		Thread.sleep(5000);
		sikuliHelper.click("Alert_Close");
		Thread.sleep(30000);
		sikuliHelper.waitTypeValTab("Cust_Num", "1");
		Thread.sleep(5000);
		sikuliHelper.click("Catalog");
		sikuliHelper.waitTypeValTab("Seq_num", "2");
		sikuliHelper.waitTypeValdoubleTab("Seq_num", "1");
		sikuliHelper.waitTypeValTab("Year", "2000");
		sikuliHelper.waitTypeValTab("make_modal", "1");
		sikuliHelper.waitTypeValdoubleTab("make_modal", "2");
		sikuliHelper.waitTypeValTab("Sequence", "0");
		sikuliHelper.waitTypeValTab("Sequence", "0");
		Thread.sleep(5000);
		sikuliHelper.waitTypeValTab("Seq_num2", "1");
		sikuliHelper.waitTypeValTab("Quantity", "1");
		sikuliHelper.waitTypeValTab("PD", "U");
		sikuliHelper.waitTypeValTab("DC", "Y");
		sikuliHelper.waitTypeValTab("Ok2", "Y");
		sikuliHelper.click("Invoice");
		sikuliHelper.click("Checkout");
		sikuliHelper.click("Error_Ok1");
		sikuliHelper.waitTypeValTab("Seqforpay", "1");
		sikuliHelper.click("Submit");
		sikuliHelper.waitTypeValTab("PO_Number", "12345");
		sikuliHelper.click("Print");
		sikuliHelper.click("Error_Ok1");
		sikuliHelper.click("Ok_Checkout");
		sikuliHelper.click("Logout");
		sikuliHelper.click("Logout1");
		sikuliHelper.click("Exit_Tams");
		sikuliHelper.click("Yes_Warning");
	}
	
}
